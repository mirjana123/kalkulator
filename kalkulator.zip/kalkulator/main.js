function calc() {
    var a = parseInt(document.querySelector("#broj1").value);
    var b = parseInt(document.querySelector("#broj2").value);
    var op = document.querySelector("#operator").value;
    var calculate
    
    if (op == "sabiranje") {
      calculate = a + b;
    } else if (op == "oduzimanje") {
      calculate = a - b;
    } else if (op == "mnozenje") {
      calculate = a * b;
    } else if (op == "deljenje") {
      calculate = a / b;
    }
  
    document.querySelector("#rezultat").innerHTML = calculate;
}